#include <iostream>
#include "Jeu.h"

using namespace std;

int main()
{
    cout << "----   Pokemon ----" << endl;

    Jeu maPartie;

    maPartie.Jouer();

    return 0;
}
