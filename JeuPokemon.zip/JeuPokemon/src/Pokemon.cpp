#include "Pokemon.h"

Pokemon::Pokemon(std::string nom,std::string type1,int prix,int pv,int niveau,int attaque,int attaqueSpe,int defense,int defenseSpe,int vitesse)
{
    _nom = nom;
    _type1 = type1;
    _prix = prix;
    _pv = pv;
    _niveau = niveau;
    _attaque = attaque;
    _attaqueSpe = attaqueSpe;
    _defense = defense;
    _defenseSpe = _defenseSpe;
    _vitesse = _vitesse;
}


void Pokemon::AjouterAttaque(Attaque& attaque)
{
    _vectorAttaquePokemon.push_back(&attaque);
}

void Pokemon::AjouterBaie(Baie& baie)
{
    _vectorBaie.push_back(&baie);
}

void Pokemon::Attaquer(Pokemon& pokemonDef,Attaque& attaqueUtil)
{
    double degats;

    degats = attaqueUtil.CalculerDegats(this,&pokemonDef);

    int pvPokemonDef = pokemonDef.GetPv();
    pvPokemonDef-=degats;
    pokemonDef.SetPv(pvPokemonDef);
}




void Pokemon::UtiliserObjet()
{
    string reponse;
    Baie* Oran = _vectorBaie[0];
    cout << endl << "Voulez vous utiliser votre objet ?(oui/non)" << endl;
    cin >> reponse;
    if(reponse=="oui")
    {
        Oran->Action(*this);
        /*_vectorBaie.erase(0);*/
    }
}


int Pokemon::EstKO()
{
    int nbPpAttaqueNul=0;
    int nb_Element_Vector = 0;
    nb_Element_Vector = _vectorAttaquePokemon.size();
    for (int i=0;i<nb_Element_Vector;i++)
    {
        int pp =_vectorAttaquePokemon[i]->GetPp();
        if(pp=0)
        {
            nbPpAttaqueNul++;
        }
    }
    if(_pv>0&&nbPpAttaqueNul<nb_Element_Vector)
    {
        return 0;
    }
    else if(_pv==0||nbPpAttaqueNul==nb_Element_Vector)
    {
        return 1;
    }
}

void Pokemon::AfficherAttaques()
{
    int nb_Element_Vector = 0;
    nb_Element_Vector = _vectorAttaquePokemon.size();
    for (int i=0;i<nb_Element_Vector;i++)
    {
        cout << endl << i+1 << ".";
        _vectorAttaquePokemon[i]->Afficher();
    }
}

Attaque* Pokemon::RecupererAttaque(int numAtt)
{
    return _vectorAttaquePokemon[numAtt];
}

void Pokemon::Afficher()
{
    cout << endl;
    cout << "Nom : " << _nom << endl;
    cout << "Vie : " << _pv << endl;
    cout << "Niveau : " << _niveau << endl;
    cout << "Type: " << _type1<< endl;
}

int Pokemon::GetPv()
{
    return _pv;
}

void Pokemon::SetPv(int pv)
{
    _pv=pv;
}

int Pokemon::GetPrix()
{
    return _prix;
}

void Pokemon::SetPrix(int prix)
{
    _prix=prix;
}


int Pokemon::GetNiveau()
{
    return _niveau;
}
int Pokemon::GetAttaque()
{
    return _attaque;
}
int Pokemon::GetAttaqueSpe()
{
    return _attaqueSpe;
}
int Pokemon::GetDefense()
{
    return _defense;
}
int Pokemon::GetDefenseSpe()
{
    return _defenseSpe;
}
int Pokemon::GetVitesse()
{
    return _vitesse;
}


string Pokemon::GetType1()
{
    return _type1;
}


/*string Pokemon::GetVectorAttaque()
{
    return _vectorAttaquePokemon;
}*/
