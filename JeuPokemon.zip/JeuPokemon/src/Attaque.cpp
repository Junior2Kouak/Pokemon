#include "Attaque.h"
#include "Pokemon.h"
#include <string>

Attaque::Attaque(std::string nom,std::string type,std::string categorie,int precision,int puissance,int pp)
{
   _nom = nom;
   _type = type;
   _categorie = categorie;
   _precision = precision;
   _puissance = puissance;
   _pp = pp;

}

/*double Attaque::CalculerDegats(Pokemon& pokemonAtt,Pokemon& pokemonDef)
{
    double degatsAttaque=0.0,STAB=1,CM=1;
    int ATTAQUE=0,DEFENSE=0;

    if(_categorie='Special')
    {
        ATTAQUE = pokemonAtt._attaqueSpe;
        DEFENSE = pokemonDef._defenseSpe;
    }
    else if(_categorie='Physique')
    {
        ATTAQUE = pokemonAtt._attaque;
        DEFENSE = pokemonDef._defense;
    }

    if(_type==pokemonAtt._type1)
    {
        STAB = 1.5;
    }

    CM = STAB*_precision;

    degatsAttaque=(((pokemonAtt._niveau*0.4+2)*ATTAQUE*100)/(DEFENSE*50)+2)*CM;

    return degatsAttaque;
}*/

void Attaque::Afficher()
{
    cout << endl;
    cout << "Nom : " << _nom << endl;
    cout << "Type : " << _type << endl;
    cout << "Categorie : " << _categorie << endl;
    cout << "Precision : " << _precision<< endl;
    cout << "Puissance : " << _puissance<< endl;
    cout << "PP : " << _pp<< endl;
}

string Attaque::GetCategorie()
{
    return _categorie;
}

string Attaque::GetType()
{
    return _type;
}



int Attaque::CalculerDegats(Pokemon* pokemonAtt,Pokemon* PokemonDef)
{
    int pvPerdu=0;
    int Niv = 1;
    Niv = pokemonAtt->GetNiveau();
    int Att = 0;
    int Def = 0;
    double STAB = 1.0;
    double CM;
    string type1PokemonAtt = pokemonAtt->GetType1();

    if(_categorie=="Physique"){

        Att = pokemonAtt->GetAttaque();
        Def = PokemonDef->GetDefense();

    }
    else if (_categorie=="Special")
    {
        Att = pokemonAtt->GetAttaqueSpe();
        Def = PokemonDef->GetDefenseSpe();
    }

    if(type1PokemonAtt==_type)
    {
        STAB = 1.5;
    }

    CM = STAB * _precision;

    pvPerdu = (((Niv*0.4+2)*Att*_puissance)/(Def*50)+2)*CM;


    return pvPerdu;
}


int Attaque::GetPp()
{
    return _pp;
}
