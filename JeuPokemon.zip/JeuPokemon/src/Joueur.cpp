#include "Joueur.h"
#include "Pokemon.h"
#include "Attaque.h"
#include <iostream>
#include <vector>

using namespace std;

Joueur::Joueur(string nom,int argent)
{
    _nom = nom;
    _argent = argent;
}


void Joueur::ChoisirPokemon()
{
    int p1,p2,p3;
    /*Pokemon(std::string _nom,std::string _type1,int _prix,int _pv,int _niveau,int _attaque,int _attaqueSpe,int _defense,int _defenseSpe,int _vitesse);*/
    // nom, type, prix, pv, Niveau, Attaque, attaqueSPE, Def, DefSPE, Vitesse

    //nom, type, categorie, precision, puissance, pp)

    //Tortank
    Pokemon* Tortank = new Pokemon("Tortank", "Eau", 800, 79, 3, 83, 85, 100, 105, 78);

    Attaque* Hydraucanon = new Attaque("Hydraucanon", "Normal","Special",80,110,5);
    Attaque* Ecume = new Attaque("Ecume", "Eau","Special",100,40,30);

    Attaque* Cascade = new Attaque("Cascade", "Normal","Physique",100,80,15);
    Attaque* Plongee = new Attaque("Plongee", "Eau","Physique",57,27,64);//A Revoir

    Tortank->AjouterAttaque(*Hydraucanon);
    Tortank->AjouterAttaque(*Ecume);
    Tortank->AjouterAttaque(*Cascade);
    Tortank->AjouterAttaque(*Plongee);


    //Ratatac
    Pokemon* Ratatac = new Pokemon("Ratatac", "Normal", 800, 55, 2, 81,50,60,70,97);

    Attaque* Tripattaque = new Attaque("Tripattaque", "Normal","Special",25,13,12);
    Attaque* Meteores = new Attaque("Meteores", "Eau","Special",57,27,64);

    Attaque* Escalade = new Attaque("Escalade", "Normal","Physique",25,13,12);
    Attaque* Pilonnage = new Attaque("Pilonnage", "Eau","Physique",57,27,64);

    Ratatac->AjouterAttaque(*Tripattaque);
    Ratatac->AjouterAttaque(*Meteores);
    Ratatac->AjouterAttaque(*Escalade);
    Ratatac->AjouterAttaque(*Pilonnage);

    //Pikachu
    Pokemon* Pikachu = new Pokemon("Pikachu", "Electrik", 800, 55, 1, 55, 50, 40, 50, 90);

    Attaque* Eclair = new Attaque("Eclair", "Normal","Special",25,13,12);
    Attaque* BouleElek = new Attaque("BouleElek", "Eau","Special",57,27,64);

    Attaque* PoingEclair = new Attaque("PoingEclair", "Normal","Physique",25,13,12);
    Attaque* CrossEclair = new Attaque("CrossEclair", "Eau","Physique",57,27,64);

    Pikachu->AjouterAttaque(*Eclair);
    Pikachu->AjouterAttaque(*BouleElek);
    Pikachu->AjouterAttaque(*PoingEclair);
    Pikachu->AjouterAttaque(*CrossEclair);

    //Ponyta
    Pokemon* Ponyta = new Pokemon("Ponyta", "Feu", 800, 50, 3, 55, 50, 40, 50, 90);

    Attaque* RafaleFeu = new Attaque("RafaleFeu", "Normal","Special",25,13,12);
    Attaque* Flammeche = new Attaque("Flammeche", "Eau","Special",57,27,64);

    Attaque* TacleFeu = new Attaque("TacleFeu", "Normal","Physique",25,13,12);
    Attaque* CrocsFeu = new Attaque("CrocsFeu", "Eau","Physique",57,27,64);

    Ponyta->AjouterAttaque(*RafaleFeu);
    Ponyta->AjouterAttaque(*Flammeche);
    Ponyta->AjouterAttaque(*TacleFeu);
    Ponyta->AjouterAttaque(*CrocsFeu);

    //Smogo
    Pokemon* Smogo = new Pokemon("Smogo", "Poisson", 800, 40, 1, 52,43,60,50,65);

    Attaque* BainDeSmog = new Attaque("BainDeSmog", "Normal","Special",25,13,12);
    Attaque* Eructation = new Attaque("Eructation", "Eau","Special",57,27,64);

    Attaque* Detricanon = new Attaque("Detricanon", "Normal","Physique",25,13,12);
    Attaque* DirectToxik = new Attaque("DirectToxik", "Eau","Physique",57,27,64);

    Smogo->AjouterAttaque(*BainDeSmog);
    Smogo->AjouterAttaque(*Eructation);
    Smogo->AjouterAttaque(*Detricanon);
    Smogo->AjouterAttaque(*DirectToxik);

    Baie* Oran = new Baie("Oran","+10PV",10);

    cout << "---    Liste Pokemons   ---" << endl;
    cout << "1. ";
    Tortank->Afficher();
    cout << "2. ";
    Pikachu->Afficher();
    cout << "3. ";
    Ratatac->Afficher();
    cout << "4. ";
    Ponyta->Afficher();
    cout << "5. ";
    Smogo->Afficher();

    cout << endl << endl << "Choisissez 3 Pokemons" << endl;

    cout << endl << "Pokemon 1 :";
    cin >> p1;

    if(p1==1)
    {
        AjouterPokemon(*Tortank);
    }
    else if(p1==2)
    {
        AjouterPokemon(*Pikachu);
    }
    else if(p1==3)
    {
        AjouterPokemon(*Ratatac);
    }
    else if(p1==4)
    {
        AjouterPokemon(*Ponyta);
    }
    else if(p1==5)
    {
        AjouterPokemon(*Smogo);
    }


    Pokemon* pokemon1 = _vectorPokemons[0];

    string c="";
    cout << endl << "Voulez acheter une Baie pour ce Pokemon ? oui/non :";
    cin >> c;

    if(c=="oui")
    {
        pokemon1->AjouterBaie(*Oran);
        cout << "Oran ajoute dans le sac a objet du pokemon" <<endl;
    }


    cout << endl << "Pokemon 2 :";
    cin >> p2;

     if(p2==1)
    {
        AjouterPokemon(*Tortank);
    }
    else if(p2==2)
    {
        AjouterPokemon(*Pikachu);
    }
    else if(p2==3)
    {
        AjouterPokemon(*Ratatac);
    }
    else if(p2==4)
    {
        AjouterPokemon(*Ponyta);
    }
    else if(p2==5)
    {
        AjouterPokemon(*Smogo);
    }


    c="";
    cout << endl << "Voulez acheter une Baie pour ce Pokemon ? oui/non :";
    cin >> c;

    Pokemon* pokemon2 = _vectorPokemons[1];

    if(c=="oui")
    {
        pokemon2->AjouterBaie(*Oran);
        cout << "Oran ajoute dans le sac a objet du pokemon" <<endl;
    }


    cout << endl << "Pokemon 3 :";
    cin >> p3;
     if(p3==1)
    {
        AjouterPokemon(*Tortank);
    }
    else if(p3==2)
    {
        AjouterPokemon(*Pikachu);
    }
    else if(p3==3)
    {
        AjouterPokemon(*Ratatac);
    }
    else if(p3==4)
    {
        AjouterPokemon(*Ponyta);
    }
    else if(p3==5)
    {
        AjouterPokemon(*Smogo);
    }

    Pokemon* pokemon3 = _vectorPokemons[2];

   c="";
    cout << endl << "Voulez acheter une Baie pour ce Pokemon ? oui/non :";
    cin >> c;

    if(c=="oui")
    {
        pokemon3->AjouterBaie(*Oran);
        cout << "Oran ajoute dans le sac a objet du pokemon" <<endl;
    }

    cout << endl << "Vos Pokemon sont : " << endl;

    AfficherPokemons();



}

void Joueur::MaFonction(int choix)
{

}

void Joueur::AjouterPokemon(Pokemon& pokemon)
{
    int prix;
    prix=pokemon.GetPrix();
    _vectorPokemons.push_back(&pokemon);
    _argent-=prix;

}


Attaque* Joueur::ChoisirAttaque(Pokemon& pokemon)
{
    int choix=0;
    string nomJoueur;
    pokemon.AfficherAttaques();
    /*nomJoueur=this->GetNom();

    cout << endl << nomJoueur;*/
    cout << " A vous de jouer.";

    cout << endl << "Choisissez votre Attaque : ";
    cin >> choix;

    Attaque* AttaqueChoisie = pokemon.RecupererAttaque(choix);

    return AttaqueChoisie;
}



Pokemon* Joueur::RecupererPokemon(int numPokemon)
{

    return _vectorPokemons[numPokemon-1];

}

string Joueur::GetNom()
{
    return _nom;
}

int Joueur::GetMancheGagnee()
{
    return _mancheGagnee;
}

void Joueur::SetMancheGagnee(int a)
{
    _mancheGagnee=a;
}


void Joueur::AfficherPokemons()
{
    int nb_Element_Vector = 0;
    nb_Element_Vector = _vectorPokemons.size();

    for (int i=0;i<nb_Element_Vector;i++)
    {
        _vectorPokemons[i]->Afficher();
    }
}


void Joueur::Afficher()
{

    cout << endl;
    cout << "Nom : " << _nom << endl;
    cout << "Manche Gagnee : " << _mancheGagnee << endl;
    cout << "Argent : " << _argent << endl;

}
