#include "Baie.h"

Baie::Baie(std::string nom,std::string description,int restaurationPV)
{
    _nom = nom;
    _description = description;
    _restaurationPV = restaurationPV;
}

void Baie::Afficher()
{

    cout << endl;
    cout << "Nom : " << _nom << endl;
    cout << "Description : " << _description << endl;
    cout << "Restauration : " << _restaurationPV << endl;

}

void Baie::Action(Pokemon& pokemon)
{
    int pv=pokemon.GetPv();
    pv+=_restaurationPV;
    pokemon.SetPv(pv);
}
