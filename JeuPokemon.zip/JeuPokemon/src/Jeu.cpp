#include "Jeu.h"
#include "Joueur.h"
#include <iostream>

using namespace std;

Jeu::Jeu()
{
    //ctor
}
Jeu::Jouer()
{
    string nom_j1="",nom_j2="";

    cout << endl << "Nom Joueur1 : ";
    cin >> nom_j1;

    Joueur* joueur1 = new Joueur(nom_j1,10000);

    joueur1->ChoisirPokemon();

    cout << endl << "Nom Joueur2 : ";
    cin >> nom_j2;


    Joueur* joueur2 = new Joueur(nom_j1,10000);

    joueur2->ChoisirPokemon();

    cout << endl << endl << "---- Fight ----"<< endl;
    joueur1->Afficher();

    /*Pokemon* pokemon1_J1 = joueur1->RecupererPokemon(1);

    Pokemon* pokemon1_J2 = joueur2->RecupererPokemon(1);

    Pokemon* pokemon2_J1 = joueur1->RecupererPokemon(2);

    Pokemon* pokemon2_J2 = joueur2->RecupererPokemon(2);

    Pokemon* pokemon3_J1 = joueur1->RecupererPokemon(3);

    Pokemon* pokemon3_J2 = joueur2->RecupererPokemon(3);


    cout << endl << "---    Round 1   ---" << endl;

    pokemon1_J1->Afficher();
    pokemon1_J2->Afficher();

    cout << endl << "---    Choix des Attaques   ---" << endl;

    cout << "Joueur 1" << endl;

    joueur1->ChoisirAttaque(*pokemon1_J1);

    cout << "Joueur 2" << endl;
    joueur2->ChoisirAttaque(*pokemon1_J2);*/



    for(int i=1;i<4;i++)
    {
        int pokemon1estKo=0;
        int pokemon2estKo=0;
        cout << endl << "---    Round "<< i <<"   ---" << endl;

        Pokemon* pokemon_J1_enCour = joueur1->RecupererPokemon(i);

        Pokemon* pokemon_J2_enCour = joueur2->RecupererPokemon(i);

        pokemon_J1_enCour->Afficher();
        pokemon_J2_enCour->Afficher();

        cout << endl << "---    Choix des Attaques   ---" << endl;




    do{
        cout << endl << "Joueur 1" << endl;
        Attaque* AttaqueChoisie_J1 = joueur1->ChoisirAttaque(*pokemon_J1_enCour);


        cout << endl << "Joueur 2" << endl;
        Attaque* AttaqueChoisie_J2 = joueur2->ChoisirAttaque(*pokemon_J2_enCour);

        int vitesse_pokemonJ1 = pokemon_J1_enCour->GetVitesse();
        int vitesse_pokemonJ2 = pokemon_J2_enCour->GetVitesse();


        if(vitesse_pokemonJ1>=vitesse_pokemonJ2){
            pokemon_J1_enCour->Attaquer(*pokemon_J2_enCour,*AttaqueChoisie_J1);
            pokemon2estKo = pokemon_J2_enCour->EstKO();
            if(pokemon2estKo==0){
                pokemon_J2_enCour->Attaquer(*pokemon_J1_enCour,*AttaqueChoisie_J1);
            }
        }
        else if(vitesse_pokemonJ1<vitesse_pokemonJ2)
        {

            pokemon_J2_enCour->Attaquer(*pokemon_J1_enCour,*AttaqueChoisie_J2);
            pokemon1estKo = pokemon_J1_enCour->EstKO();
            if(pokemon1estKo==0){
                pokemon_J1_enCour->Attaquer(*pokemon_J2_enCour,*AttaqueChoisie_J1);
            }

        }
    }while(pokemon2estKo==1||pokemon1estKo==1);

    if(pokemon1estKo==1&&pokemon2estKo==0)
    {
        int manche_gagne_j1;
        manche_gagne_j1=joueur1->GetMancheGagnee();
        manche_gagne_j1++;
        joueur1->SetMancheGagnee(manche_gagne_j1);
    }
    else if(pokemon1estKo==0&&pokemon2estKo==1)
    {
        int manche_gagne_j2;
        manche_gagne_j2=joueur2->GetMancheGagnee();
        manche_gagne_j2++;
        joueur2->SetMancheGagnee(manche_gagne_j2);
    }
    }

    int mG_J1=joueur1->GetMancheGagnee();
    int mG_J2=joueur2->GetMancheGagnee();

    cout << endl << "========   Resultat   ========" << endl;

    if(mG_J1>=mG_J2)
    {
        cout << endl <<"Bravo ";
        string NomVainqueur = joueur1->GetNom();
        cout << NomVainqueur;
        cout <<" , Vous avez gagne" << endl;
    }
    else if(mG_J1<=mG_J2)
    {
        cout << endl <<"Bravo ";
        string NomVainqueur = joueur2->GetNom();
        cout << NomVainqueur;
        cout <<" , Vous avez gagne" << endl;
    }




















    /*
    for(int i=1;i<4;i++)
    {
    pokemon1estKo=0;
    pokemon2estKo=0;
    do{
        joueur1->ChoisirAttaque(*pokemon[i]);
        joueur2->ChoisirAttaque(*pokemon[i]);

        vitesse_pokemon1;
        vitesse_pokemon2;

        if(vitesse_pokemon1>=vitesse_pokemon2){
            pokemon1->Attaque(pokemon2);
            pokemon2estKo = pokemon2.EstKO();
            if(pokemon2estKo=0){
                pokemon2->Attaque(pokemon1);
            }
        }
        else
        {

            pokemon2->Attaque(pokemon1);
            pokemon1estKo = pokemon1.EstKO();
            if(pokemon1estKo=0){
                pokemon1->Attaque(pokemon2);
            }

        }
    }while(pokemon2estKo==1||pokemon1estKo==1);
    if(pokemon1estKo=1&&pokemon2estKo=0)
    {
        manche_gagne_j1++;
    }
    else if(pokemon1estKo=0&&pokemon2estKo=1)
    {
        manche_gagne_j2++;
    }
    }

    if(manche_gagne_j1>manche_gagne_j2)
    {

    }
    elseif(manche_gagne_j1<manche_gagne_j2)
    {

    }


    */

}
