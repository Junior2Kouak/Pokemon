#ifndef POKEMON_H
#define POKEMON_H
#include <vector>
#include "Attaque.h"
#include "Baie.h"
#include "Pokemon.h"
#include <iostream>

class Attaque;
class Baie;
using namespace std;

class Pokemon
{
    public:
        Pokemon(std::string nom,std::string type1,int prix,int pv,int niveau,int attaque,int attaqueSpe,int defense,int defenseSpe,int vitesse);
        void AjouterAttaque(Attaque& attaque);
        void Attaquer(Pokemon& pokemonDef,Attaque& attaqueUtil);
        void UtiliserObjet();
        int EstKO();
        void AfficherAttaques();
        void Afficher();
        void AjouterBaie(Baie& baie);
        int GetPv();
        void SetPv(int pv);
        int GetPrix();
        void SetPrix(int prix);
        int GetNiveau();
        int GetAttaque();
        int GetAttaqueSpe();
        int GetDefense();
        int GetDefenseSpe();
        int GetVitesse();
        Attaque* RecupererAttaque(int numAtt);
        string GetType1();
        string GetVectorAttaque();

    private:
        std::string _nom;
        int _prix;
        std::string _type1;
        std::string _type2;
        int _pv;
        int _niveau;
        int _attaque;
        int _attaqueSpe;
        int _defense;
        int _defenseSpe;
        int _vitesse;
        std::vector<Attaque* > _vectorAttaquePokemon;
        std::vector<Baie* > _vectorBaie;

};

#endif // POKEMON_H
