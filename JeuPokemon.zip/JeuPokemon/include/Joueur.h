#ifndef JOUEUR_H
#define JOUEUR_H
#include <vector>
#include "Pokemon.h"
#include <iostream>

using namespace std;

class Joueur
{
    public:
        Joueur(string nom,int argent);
        void ChoisirPokemon();
        void AjouterPokemon(Pokemon& pokemon);
        Attaque* ChoisirAttaque(Pokemon& pokemon);
        Pokemon* RecupererPokemon(int numPokemon);
        void AfficherPokemons();
        void Afficher();
        void AcheterBaie();
        void MaFonction(int choix);
        int GetMancheGagnee();
        void SetMancheGagnee(int a);
        string GetNom();

    private:
        std::string _nom;
        std::vector<Pokemon*> _vectorPokemons;
        int _mancheGagnee;
        int _argent;

};

#endif // JOUEUR_H
