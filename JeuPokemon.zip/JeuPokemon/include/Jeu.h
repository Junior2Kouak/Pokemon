#ifndef JEU_H
#define JEU_H


class Jeu
{
    public:
        Jeu();
        Jouer();

    private:
};

#endif // JEU_H
