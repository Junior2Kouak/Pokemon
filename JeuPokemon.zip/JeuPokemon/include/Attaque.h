#ifndef ATTAQUE_H
#define ATTAQUE_H
#include <vector>
#include "Pokemon.h"
#include "Attaque.h"
#include <iostream>

class Pokemon;
using namespace std;

class Attaque
{
    public:
        Attaque(std::string _nom,std::string _type,std::string _categorie,int _precision,int _puissance,int _pp);
        /*double CalculerDegats(Pokemon& pokemonAtt,Pokemon& pokemonDef);*/
        void Afficher();

        int CalculerDegats(Pokemon* pokemonAtt,Pokemon* PokemonDef);

        int GetPp();

    private:
        std::string _nom;
        std::string _type;
        std::string _categorie;
        std::string GetCategorie();
        std::string GetType();
        int _precision;
        int _puissance;
        int _pp;
};

#endif // ATTAQUE_H
