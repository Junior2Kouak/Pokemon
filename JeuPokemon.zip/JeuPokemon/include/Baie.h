#ifndef BAIE_H
#define BAIE_H
#include "Pokemon.h"
#include <iostream>

class Pokemon;
using namespace std;

class Baie
{
    public:
        Baie(std::string _nom,std::string _description,int _restaurationPV);
        void Action(Pokemon& pokemon);
        void Afficher();

    private:
        std::string _nom;
        std::string _description;
        int _restaurationPV;
};

#endif // BAIE_H
